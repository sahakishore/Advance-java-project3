create table result(rollno number(20) not null, name varchar2(4000), result varchar2(4000), grade varchar2(4000));
